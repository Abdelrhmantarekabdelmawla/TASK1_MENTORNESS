from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd
import pickle
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# Load the trained model
with open('salary_model.pkl', 'rb') as f:
    model = pickle.load(f)

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")


class SalaryPredictionRequest(BaseModel):
    first_name: str
    last_name: str
    sex: str
    doj: str
    current_date: str
    designation: str
    age: int
    unit: str
    leaves_used: int
    leaves_remaining: int
    ratings: float
    past_exp: int


@app.post("/predict")
def predict_salary(request: SalaryPredictionRequest):
    try:
        # Create a DataFrame from the request
        data = pd.DataFrame([request.dict()])

        # Preprocess the data (example: encoding categorical variables)
        # Add your preprocessing steps here

        # Predict the salary
        prediction = model.predict(data)

        return {"predicted_salary": prediction[0]}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/")
def read_root():
    return FileResponse("static/index.html")
